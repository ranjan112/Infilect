package com.example.splashscreen;

import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;


public class M4 extends Activity{
	
	 ListView list;
	    String[] web = {"Causes","Symptoms","Treatment"
	    		};
	    Integer[] imageId = {
	            R.drawable.eye,
	            R.drawable.eye,
	            R.drawable.eye,
	           
	           
	    };
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        requestWindowFeature(Window.FEATURE_LEFT_ICON);
			 setContentView(R.layout.activity_menu_doc);
			 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);
			 this.setTitleColor(Color.GREEN); 
	        setContentView(R.layout.activity_m4);
	       
	        
	        
	        
	        Health_Dictionary adapter = new Health_Dictionary(M4.this, web, imageId);
	        list=(ListView)findViewById(R.id.list);
	                list.setAdapter(adapter);
	                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
	 
	                    @Override
	                    public void onItemClick(AdapterView<?> parent, View view,
	                                            int position, long id) {
	                        Toast.makeText(M4.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
	                        if (position == 0) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),M5 .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                       
	                        if (position == 1) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),M6 .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                        
	                        if (position == 2) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(), M7.class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                    }
	                });
	                
	               	
	                
	               		
	               	
	 
	    }}
		
		
	 
	