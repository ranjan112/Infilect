package com.example.splashscreen;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.view.Window;

public class Menu_doc extends Activity {

 ImageView imgClick,imgClick2,imgClick3,imgClick4,imgClick5,imgClick6;
 //TextView tv;
 ImageView imageView7;
 @Override
 protected void onCreate(Bundle savedInstanceState) {
 super.onCreate(savedInstanceState);
 requestWindowFeature(Window.FEATURE_LEFT_ICON);
 setContentView(R.layout.activity_menu_doc);
 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);

 setContentView(R.layout.activity_menu_doc);
 this.setTitleColor(Color.GREEN); 
 
 imgClick = (ImageView)findViewById(R.id.imageView1);
 imgClick2 = (ImageView)findViewById(R.id.imageView2);
 imgClick3 = (ImageView)findViewById(R.id.imageView3);
 imgClick4 = (ImageView)findViewById(R.id.imageView4);
 imgClick5 = (ImageView)findViewById(R.id.imageView5);

 
 imgClick6 = (ImageView)findViewById(R.id.imageView6);
//TextView tv=(TextView)findViewById(R.id.textView1);
 imgClick.setOnClickListener(new View.OnClickListener() {
 
 @Override
 public void onClick(View v) {
 
 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
	 Intent i = new Intent(getApplicationContext(), Exer.class);
     
	 startActivity(i);
	 
 }});
 
 imgClick2.setOnClickListener(new View.OnClickListener() {
	 
	 @Override
	 public void onClick(View v) {
	 
	 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
 Intent i = new Intent(getApplicationContext(), MainPage.class);
	     
		 startActivity(i);
		
	 }});
 
imgClick3.setOnClickListener(new View.OnClickListener() {
	 
	 @Override
	 public void onClick(View v) {
	 
	 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
		 Intent i = new Intent(getApplicationContext(), Bmi.class);
	     
		 startActivity(i);
	 }});

imgClick4.setOnClickListener(new View.OnClickListener() {
	 
	 @Override
	 public void onClick(View v) {
	 
	 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
		 Intent i = new Intent(getApplicationContext(), Speechtext.class);
	     
		 startActivity(i);
	 }});


imgClick6.setOnClickListener(new View.OnClickListener() {
	 
	 @Override
	 public void onClick(View v) {
	 
	 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
		 Intent i = new Intent(getApplicationContext(), Blind.class);
	     
		 startActivity(i);
	 }});
imgClick5.setOnClickListener(new View.OnClickListener() {
	 
	 @Override
	 public void onClick(View v) {
	 
	 //Toast.makeText(Menu_doc.this, "You clicked on ImageView", Toast.LENGTH_LONG).show();
		 Intent i = new Intent(getApplicationContext(), Feedback.class);
	     
		 startActivity(i);
	 }});

 
 
 
 }
}