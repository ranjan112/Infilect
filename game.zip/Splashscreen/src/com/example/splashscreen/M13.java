package com.example.splashscreen;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;

public class M13 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		 setContentView(R.layout.activity_menu_doc);
		 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);
		 this.setTitleColor(Color.GREEN); 
		setContentView(R.layout.activity_m13);
	}


}
