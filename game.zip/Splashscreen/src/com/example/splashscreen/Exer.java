package com.example.splashscreen;

import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

public class Exer extends Activity{
	
	 ListView list;
	 
	
	    String[] web = {"Basic Crunch","Push-up","Jumping Jacks","Squat","High Knees","Lunge","Bench Dip"
	    		};
	    Integer[] imageId = {
	            R.drawable.b_cr,
	            R.drawable.p_up,
	            R.drawable.j_up,
	            R.drawable.s_up,
	            R.drawable.h_up,
	            R.drawable.l_up,
	            R.drawable.b_up,
	           
	           
	    };
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        requestWindowFeature(Window.FEATURE_LEFT_ICON);
			 setContentView(R.layout.activity_menu_doc);
			 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);
			 this.setTitleColor(Color.GREEN); 
			
	        setContentView(R.layout.activity_exer);
	       
	        
	        
	        
	        Health_Dictionary adapter = new Health_Dictionary(Exer.this, web, imageId);
	        list=(ListView)findViewById(R.id.list);
	                list.setAdapter(adapter);
	                //list.setTextColor(Color.parseColor("#fe00fb"));
	            
	                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
	 
	                    @Override
	                    public void onItemClick(AdapterView<?> parent, View view,
	                                            int position, long id) {
	                        Toast.makeText(Exer.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
	                       
	                        if (position == 0) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Basic .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));


	                        }
	                        if (position == 1) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Pup .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                        if (position == 2) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Leg .class);
	                            startActivityForResult(myIntent, 0);

	                            view.setBackgroundColor(Color.parseColor("#44bec7"));
	                        }
	                        if (position == 3) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Squat .class);
	                            startActivityForResult(myIntent, 0);

	                            view.setBackgroundColor(Color.parseColor("#44bec7"));
	                        }
	                        if (position == 4) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),High .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                       
	                        if (position == 5) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Lunge .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                        if (position == 6) {
	                            //code specific to first list item
	                            Intent myIntent = new Intent(view.getContext(),Bench_Dip .class);
	                            startActivityForResult(myIntent, 0);
	                            view.setBackgroundColor(Color.parseColor("#44bec7"));

	                        }
	                       
	                      
	                    }
	                });
	                
	               	
	                
	               		
	               	
	 
	    }}
		
		
	 
	