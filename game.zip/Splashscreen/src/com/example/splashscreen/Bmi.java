package com.example.splashscreen;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;


public class Bmi extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		 setContentView(R.layout.activity_menu_doc);
		 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);
		 this.setTitleColor(Color.GREEN); 
		setContentView(R.layout.activity_bmi);
		final EditText e1 = (EditText) findViewById(R.id.et1);
		final EditText e2 = (EditText) findViewById(R.id.et2);
		final TextView tv4 = (TextView) findViewById(R.id.tv5);

		findViewById(R.id.ib1).setOnClickListener(new View.OnClickListener() {

		// Logic for validation, input can't be empty
		@Override
		public void onClick(View v) {

		String str1 = e1.getText().toString();
		String str2 = e2.getText().toString();

		if(TextUtils.isEmpty(str1)){
		e1.setError("Please enter your weight");
		e1.requestFocus();
		return;
		}

		if(TextUtils.isEmpty(str2)){
		e2.setError("Please enter your height");
		e2.requestFocus();
		return;
		}

		//Get the user values from the widget reference
		float weight = Float.parseFloat(str1);
		float height = Float.parseFloat(str2)/100;

		//Calculate BMI value
		float bmiValue = calculateBMI(weight, height);

		//Define the meaning of the bmi value
		String bmiInterpretation = interpretBMI(bmiValue);

		tv4.setText(String.valueOf(bmiValue + "-" + bmiInterpretation));

		}
		});

		}

		//Calculate BMI
		private float calculateBMI (float weight, float height) {
		return (float) (weight / (height * height));
		}

		// Interpret what BMI means
		private String interpretBMI(float bmiValue) {

		if (bmiValue < 16) {
		return "You are severely underweight";
		} else if (bmiValue < 18.5) {

		return "You are underweight";
		} else if (bmiValue < 25) {

		return "You are Normal";
		} else if (bmiValue < 30) {

		return "Yor are Overweight";
		} else {
		return "You are Obese";
		}
		}
		
	}


