package com.example.splashscreen;

//import com.login.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.TextView;

public class Splash extends Activity {
	TextView tv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		 setContentView(R.layout.activity_menu_doc);
		 setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.sh);
		 this.setTitleColor(Color.GREEN); 
		setContentView(R.layout.activity_splash);
		
		tv=(TextView)findViewById(R.id.textView1);
Thread splash_screen=new Thread(){
	public void run(){
		try{
			sleep(5000);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			startActivity(new Intent(getApplicationContext(),Menu_doc.class));
			finish();
		}
	}
};
splash_screen.start();
	}}

	